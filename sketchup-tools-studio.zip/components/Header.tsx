
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useTranslations } from '../lib/i18n';
import { languages, Language } from '../lib/translations';
import { motion } from 'framer-motion';
import { Menu, X, Globe, ChevronDown } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

const Header: React.FC = () => {
  const { t, language, setLanguage } = useTranslations();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);

  const navLinks = [
    { to: '/tools', label: t('nav.tools') },
    { to: '/tutorials', label: t('nav.tutorials') },
    { to: '/pricing', label: t('nav.pricing') },
    { to: '/download', label: t('nav.download') },
    { to: '/faq', label: t('nav.faq') },
  ];

  const activeLinkStyle = {
    color: 'hsl(var(--foreground))',
  };

  const navLinkClass = "text-sm font-medium text-muted-foreground transition-colors hover:text-foreground";

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur-sm">
      <div className="container mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <NavLink to="/" className="flex items-center space-x-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="font-bold text-lg">Studiø</span>
        </NavLink>
        
        <nav className="hidden md:flex items-center space-x-6">
          {navLinks.map(link => (
            <NavLink key={link.to} to={link.to} className={navLinkClass} style={({ isActive }) => isActive ? activeLinkStyle : {}}>
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center space-x-2">
            <ThemeToggle />
            <div className="relative">
                <button onClick={() => setIsLangOpen(!isLangOpen)} className="flex items-center justify-center p-2 rounded-md hover:bg-accent transition-colors h-9 w-9">
                    <Globe size={18} className="text-muted-foreground" />
                </button>
                {isLangOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute right-0 mt-2 w-40 origin-top-right rounded-md bg-card shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
                    >
                        <div className="py-1">
                        {languages.map(lang => (
                            <button
                                key={lang.code}
                                onClick={() => {
                                    setLanguage(lang.code as Language);
                                    setIsLangOpen(false);
                                }}
                                className={`block w-full text-left px-4 py-2 text-sm ${language === lang.code ? 'bg-accent text-accent-foreground' : 'text-card-foreground'} hover:bg-accent`}
                            >
                                {lang.name}
                            </button>
                        ))}
                        </div>
                    </motion.div>
                )}
            </div>

            <button
            className="md:hidden p-2 rounded-md hover:bg-accent"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
            {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
        </div>
      </div>
      
      {isMenuOpen && (
        <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border/40"
        >
          <nav className="flex flex-col space-y-2 p-4">
            {navLinks.map(link => (
              <NavLink key={link.to} to={link.to} onClick={() => setIsMenuOpen(false)} className={`${navLinkClass} py-2`} style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                {link.label}
              </NavLink>
            ))}
          </nav>
        </motion.div>
      )}
    </header>
  );
};

export default Header;