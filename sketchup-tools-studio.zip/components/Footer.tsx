
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useTranslations } from '../lib/i18n';
import { Github, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
    const { t } = useTranslations();
    
    const footerNavLinks = [
        { to: '/tools', label: t('nav.tools') },
        { to: '/tutorials', label: t('nav.tutorials') },
        { to: '/pricing', label: t('nav.pricing') },
        { to: '/contact', label: t('nav.contact') },
    ];

    return (
        <footer className="bg-secondary text-secondary-foreground border-t border-border/40">
            <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div className="md:col-span-2">
                        <div className="flex items-center space-x-2 mb-4">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
                                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                                <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                                <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                            <span className="font-bold text-lg">Studiø</span>
                        </div>
                        <p className="text-muted-foreground text-sm max-w-xs">{t('footer.company')}</p>
                    </div>

                    <div>
                        <h3 className="text-sm font-semibold text-foreground tracking-wider uppercase">{t('footer.navigate')}</h3>
                        <ul className="mt-4 space-y-2">
                            {footerNavLinks.map(link => (
                                <li key={link.to}>
                                    <NavLink to={link.to} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                                        {link.label}
                                    </NavLink>
                                </li>
                            ))}
                        </ul>
                    </div>

                    <div>
                         <h3 className="text-sm font-semibold text-foreground tracking-wider uppercase">Legal</h3>
                         <ul className="mt-4 space-y-2">
                            <li><a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">{t('footer.legal.terms')}</a></li>
                            <li><a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">{t('footer.legal.privacy')}</a></li>
                         </ul>
                    </div>
                </div>

                <div className="mt-8 pt-8 border-t border-border flex flex-col sm:flex-row justify-between items-center">
                    <p className="text-sm text-muted-foreground">&copy; {new Date().getFullYear()} Studiø. All rights reserved.</p>
                    <div className="flex space-x-6 mt-4 sm:mt-0">
                        <a href="#" className="text-muted-foreground hover:text-foreground"><Twitter size={18} /></a>
                        <a href="#" className="text-muted-foreground hover:text-foreground"><Github size={18} /></a>
                        <a href="#" className="text-muted-foreground hover:text-foreground"><Linkedin size={18} /></a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
