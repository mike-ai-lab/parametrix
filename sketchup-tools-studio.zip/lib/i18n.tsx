
import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { translations, Language, languages } from './translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  // FIX: Changed return type from `string` to `any` to allow returning translation objects/arrays.
  t: (key: string, ...args: (string | number)[]) => any;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    const browserLanguage = navigator.language.split('-')[0] as Language;
    if (savedLanguage && languages.some(l => l.code === savedLanguage)) {
      setLanguageState(savedLanguage);
    } else if (languages.some(l => l.code === browserLanguage)) {
        setLanguageState(browserLanguage);
    } else {
      setLanguageState('en');
    }
  }, []);

  useEffect(() => {
    if (language === 'ar' || language === 'fa') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [language]);

  const setLanguage = (lang: Language) => {
    localStorage.setItem('language', lang);
    setLanguageState(lang);
  };

  const t = useCallback((key: string, ...args: (string | number)[]) => {
    const keys = key.split('.');
    let result: any = translations[language] || translations['en'];
    for (const k of keys) {
      result = result?.[k];
      if (result === undefined) {
        console.warn(`Translation key not found: ${key}`);
        return key;
      }
    }
    
    if (typeof result === 'string' && args.length > 0) {
      return result.replace(/{(\d+)}/g, (match, number) => {
        return typeof args[number] !== 'undefined' ? String(args[number]) : match;
      });
    }

    return result;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslations = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslations must be used within a LanguageProvider');
  }
  return context;
};