
export type Language = 'en' | 'pt-br' | 'fr' | 'de' | 'it' | 'ja' | 'ko' | 'ru' | 'es' | 'nl' | 'zh-tw' | 'ar' | 'fa';

export const languages = [
  { code: 'en', name: 'English' },
  { code: 'pt-br', name: 'Português (BR)' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' },
  { code: 'it', name: 'Italiano' },
  { code: 'nl', name: 'Nederlands' },
  { code: 'ja', name: '日本語' },
  { code: 'ko', name: '한국어' },
  { code: 'ru', name: 'Русский' },
  { code: 'zh-tw', name: '繁體中文' },
  { code: 'ar', name: 'العربية' },
  { code: 'fa', name: 'فارسی' },
];

export const translations = {
  'en': {
    nav: { home: 'Home', tools: 'Tools', tutorials: 'Tutorials', pricing: 'Pricing', download: 'Download', faq: 'FAQ', contact: 'Contact' },
    home: {
      headline: "Precision Tools for Modern SketchUp Workflows",
      subheadline: "Powerful extensions designed for automation, efficiency, and seamless integration. Offline-first and privacy-focused.",
      exploreTools: "Explore Tools",
      viewTutorials: "View Tutorials",
      vp: {
        offline: { title: "100% Offline", description: "All tools run locally on your machine. No cloud dependency." },
        privacy: { title: "Privacy-Focused", description: "Your data and designs remain yours, always. We never upload anything." },
        automation: { title: "Automated Workflows", description: "Save hours of manual work with powerful automation features." },
        integration: { title: "CNC & Fab-Ready", description: "Export clean geometry ready for CNC machines and digital fabrication." },
      },
      screenshots: "Product Showcase"
    },
    tools: {
      title: "Our Extension Suite",
      description: "A collection of powerful, reliable tools to enhance your SketchUp experience.",
      products: {
        proPack: { name: "ProPack Suite", description: "The essential toolkit for architectural visualization and construction." },
        camPlus: { name: "CAM Plus", description: "Advanced CNC preparation and g-code generation directly in SketchUp." },
        unfold: { name: "UnfoldMaster", description: "Unfold any 3D model into a flat 2D pattern for fabrication." },
        organizer: { name: "SceneOrganizer", description: "Manage complex models with advanced layer and scene management." },
        renderer: { name: "LightFrame RT", description: "A minimalist real-time renderer for quick previews and look-dev." },
        profiler: { name: "ProfileLab", description: "Create and manage complex profiles and extrusions with ease." },
      },
      viewDetails: "View Details"
    },
    tutorials: {
      title: "Guides & Tutorials",
      description: "Step-by-step guides to help you master our tools.",
      byExtension: "Tutorials for {0}",
      steps: {
        install: { title: "Installation", content: "Download the .rbz file and install it via the Extension Manager in SketchUp." },
        activate: { title: "Activation", content: "Open the extension and enter your license key to activate all Pro features." },
        basic: { title: "Basic Usage", content: "Learn the core functions and user interface of the tool." }
      }
    },
    pricing: {
      title: "Simple, Transparent Pricing",
      description: "Choose the plan that's right for you. All licenses are perpetual.",
      plans: {
        free: { name: "Free", price: "$0", features: ["Basic functionality", "Community support", "For personal use"], button: "Download Now" },
        pro: { name: "Pro", price: "$99", features: ["All features unlocked", "Priority email support", "Commercial use license", "1 year of updates"], button: "Purchase License" },
        enterprise: { name: "Enterprise", price: "Contact Us", features: ["Volume licensing", "Dedicated support", "Custom feature development", "On-site training"], button: "Get a Quote" },
      },
      perUser: "per user, one-time"
    },
    download: {
      title: "Download Latest Version",
      version: "Latest Version: 2.4.1",
      changelogTitle: "Changelog",
      changelog: [
        "Added support for SketchUp 2025.",
        "Improved performance on complex models.",
        "Fixed a bug with material exporting.",
        "UI enhancements and stability fixes."
      ],
      supported: "Supported SketchUp Versions: 2021, 2022, 2023, 2024, 2025",
      button: "Download Installer (.rbz)"
    },
    faq: {
      title: "Frequently Asked Questions",
      questions: {
        q1: { q: "How do I install the extensions?", a: "You can install the .rbz file directly from SketchUp's Extension Manager. Go to Window > Extension Manager and click 'Install Extension'." },
        q2: { q: "Is my license a subscription?", a: "No. All our licenses are perpetual. A purchase includes one year of free updates. You can continue using the software forever on the versions it supports." },
        q3: { q: "Can I use the extension on multiple computers?", a: "A single Pro license allows activation on two computers (e.g., a desktop and a laptop) for a single user." },
        q4: { q: "Do the tools require an internet connection?", a: "No. Our extensions are 100% offline and do not require an internet connection to function after activation." },
      },
      stillNeedHelp: "Still need help?",
      contactSupport: "Contact Support"
    },
    contact: {
      title: "Get In Touch",
      description: "Have a question, a feature request, or need support? We'd love to hear from you.",
      form: {
        name: "Your Name",
        email: "Your Email",
        message: "Your Message",
        button: "Send Message"
      },
      success: "Message sent! We'll get back to you soon.",
      error: "Something went wrong. Please try again."
    },
    footer: {
      company: "A small studio dedicated to crafting high-quality tools for designers and creators.",
      legal: {
        rights: "© 2025 Studiø. All rights reserved.",
        terms: "Terms of Service",
        privacy: "Privacy Policy",
      },
      navigate: "Navigate"
    }
  },
  'pt-br': {
    nav: { home: 'Início', tools: 'Ferramentas', tutorials: 'Tutoriais', pricing: 'Preços', download: 'Download', faq: 'FAQ', contact: 'Contato' },
    home: {
      headline: "Ferramentas de Precisão para Fluxos de Trabalho Modernos no SketchUp",
      subheadline: "Extensões poderosas projetadas para automação, eficiência e integração perfeita. Foco em offline e privacidade.",
      exploreTools: "Explorar Ferramentas",
      viewTutorials: "Ver Tutoriais",
      vp: {
        offline: { title: "100% Offline", description: "Todas as ferramentas rodam localmente na sua máquina. Sem dependência de nuvem." },
        privacy: { title: "Foco em Privacidade", description: "Seus dados e projetos continuam seus, sempre. Nunca enviamos nada." },
        automation: { title: "Fluxos Automatizados", description: "Economize horas de trabalho manual com recursos de automação poderosos." },
        integration: { title: "Pronto para CNC", description: "Exporte geometria limpa pronta para máquinas CNC e fabricação digital." },
      },
      screenshots: "Galeria de Produtos"
    },
    tools: {
      title: "Nossa Suíte de Extensões",
      description: "Uma coleção de ferramentas poderosas e confiáveis para aprimorar sua experiência no SketchUp.",
      products: {
        proPack: { name: "Suíte ProPack", description: "O kit de ferramentas essencial para visualização arquitetônica e construção." },
        camPlus: { name: "CAM Plus", description: "Preparação CNC avançada e geração de g-code diretamente no SketchUp." },
        unfold: { name: "UnfoldMaster", description: "Planifique qualquer modelo 3D em um padrão 2D para fabricação." },
        organizer: { name: "SceneOrganizer", description: "Gerencie modelos complexos com gerenciamento avançado de camadas e cenas." },
        renderer: { name: "LightFrame RT", description: "Um renderizador minimalista em tempo real para pré-visualizações rápidas." },
        profiler: { name: "ProfileLab", description: "Crie e gerencie perfis e extrusões complexas com facilidade." },
      },
      viewDetails: "Ver Detalhes"
    },
    pricing: {
      title: "Preços Simples e Transparentes",
      description: "Escolha o plano ideal para você. Todas as licenças são perpétuas.",
      plans: {
        free: { name: "Grátis", price: "R$0", features: ["Funcionalidade básica", "Suporte da comunidade", "Para uso pessoal"], button: "Baixar Agora" },
        pro: { name: "Pro", price: "R$499", features: ["Todos os recursos", "Suporte prioritário por email", "Licença de uso comercial", "1 ano de atualizações"], button: "Comprar Licença" },
        enterprise: { name: "Empresarial", price: "Consulte-nos", features: ["Licenciamento por volume", "Suporte dedicado", "Desenvolvimento personalizado", "Treinamento no local"], button: "Pedir Orçamento" },
      },
      perUser: "por usuário, pagamento único"
    },
    footer: {
      company: "Um pequeno estúdio dedicado a criar ferramentas de alta qualidade para designers e criadores.",
      legal: {
        rights: "© 2025 Studiø. Todos os direitos reservados.",
        terms: "Termos de Serviço",
        privacy: "Política de Privacidade",
      },
      navigate: "Navegar"
    }
  },
  // Add other languages here...
  'es': {
    nav: { home: 'Inicio', tools: 'Herramientas', tutorials: 'Tutoriales', pricing: 'Precios', download: 'Descargar', faq: 'FAQ', contact: 'Contacto' },
    home: {
        headline: "Herramientas de Precisión para Flujos de Trabajo Modernos en SketchUp",
        subheadline: "Extensiones potentes diseñadas para la automatización, eficiencia e integración perfecta. Prioridad en el trabajo sin conexión y la privacidad.",
        exploreTools: "Explorar Herramientas",
        viewTutorials: "Ver Tutoriales"
    },
    footer: {
      company: "Un pequeño estudio dedicado a crear herramientas de alta calidad para diseñadores y creadores.",
      legal: {
        rights: "© 2025 Studiø. Todos los derechos reservados.",
        terms: "Términos de Servicio",
        privacy: "Política de Privacidad",
      },
      navigate: "Navegar"
    }
  },
  'fr': {
    nav: { home: 'Accueil', tools: 'Outils', tutorials: 'Tutoriels', pricing: 'Tarifs', download: 'Télécharger', faq: 'FAQ', contact: 'Contact' },
    home: {
        headline: "Outils de Précision pour des Workflows SketchUp Modernes",
        subheadline: "Des extensions puissantes conçues pour l'automatisation, l'efficacité et une intégration transparente. Priorité au hors ligne et à la confidentialité.",
        exploreTools: "Explorer les Outils",
        viewTutorials: "Voir les Tutoriels"
    },
    footer: {
      company: "Un petit studio dédié à la création d'outils de haute qualité pour les designers et les créateurs.",
      legal: {
        rights: "© 2025 Studiø. Tous droits réservés.",
        terms: "Conditions d'utilisation",
        privacy: "Politique de confidentialité",
      },
      navigate: "Naviguer"
    }
  },
  'de': {
    nav: { home: 'Startseite', tools: 'Werkzeuge', tutorials: 'Anleitungen', pricing: 'Preise', download: 'Herunterladen', faq: 'FAQ', contact: 'Kontakt' },
    home: {
        headline: "Präzisionswerkzeuge für moderne SketchUp-Workflows",
        subheadline: "Leistungsstarke Erweiterungen für Automatisierung, Effizienz und nahtlose Integration. Offline-first und datenschutzorientiert.",
        exploreTools: "Werkzeuge entdecken",
        viewTutorials: "Anleitungen ansehen"
    },
    footer: {
      company: "Ein kleines Studio, das hochwertige Werkzeuge für Designer und Entwickler herstellt.",
      legal: {
        rights: "© 2025 Studiø. Alle Rechte vorbehalten.",
        terms: "Nutzungsbedingungen",
        privacy: "Datenschutz-Bestimmungen",
      },
      navigate: "Navigieren"
    }
  },
  'ja': {
    nav: { home: 'ホーム', tools: 'ツール', tutorials: 'チュートリアル', pricing: '価格', download: 'ダウンロード', faq: 'FAQ', contact: 'お問い合わせ' },
    home: {
        headline: "現代のSketchUpワークフローのための精密ツール",
        subheadline: "自動化、効率性、シームレスな統合のために設計された強力な拡張機能。オフラインファーストでプライバシー重視。",
        exploreTools: "ツールを探す",
        viewTutorials: "チュートリアルを見る"
    },
    footer: {
      company: "デザイナーとクリエーターのための高品質なツールを作成することに専念する小さなスタジオ。",
      legal: {
        rights: "© 2025 Studiø. 全著作権所有。",
        terms: "利用規約",
        privacy: "プライバシーポリシー",
      },
      navigate: "ナビゲート"
    }
  },
  'ar': {
    nav: { home: 'الرئيسية', tools: 'الأدوات', tutorials: 'الدروس', pricing: 'الأسعار', download: 'تنزيل', faq: 'الأسئلة الشائعة', contact: 'اتصل بنا' },
    home: {
        headline: "أدوات دقيقة لسير عمل SketchUp الحديث",
        subheadline: "ملحقات قوية مصممة للأتمتة والكفاءة والتكامل السلس. تعمل بدون اتصال بالإنترنت وتركز على الخصوصية.",
        exploreTools: "استكشف الأدوات",
        viewTutorials: "عرض الدروس"
    },
    footer: {
      company: "استوديو صغير مكرس لصناعة أدوات عالية الجودة للمصممين والمبدعين.",
      legal: {
        rights: "© 2025 Studiø. جميع الحقوق محفوظة.",
        terms: "شروط الخدمة",
        privacy: "سياسة الخصوصية",
      },
      navigate: "التنقل"
    }
  },
  'fa': {
    nav: { home: 'خانه', tools: 'ابزارها', tutorials: 'آموزش‌ها', pricing: 'قیمت‌گذاری', download: 'دانلود', faq: 'سوالات متداول', contact: 'تماس' },
    home: {
        headline: "ابزارهای دقیق برای گردش کار مدرن SketchUp",
        subheadline: "افزونه‌های قدرتمند طراحی شده برای اتوماسیون، کارایی و یکپارچه‌سازی بی‌نقص. آفلاین و متمرکز بر حریم خصوصی.",
        exploreTools: "کاوش ابزارها",
        viewTutorials: "مشاهده آموزش‌ها"
    },
    footer: {
      company: "یک استودیوی کوچک که به ساخت ابزارهای با کیفیت بالا برای طراحان و سازندگان اختصاص دارد.",
      legal: {
        rights: "© 2025 Studiø. تمام حقوق محفوظ است.",
        terms: "شرایط خدمات",
        privacy: "سیاست حفظ حریم خصوصی",
      },
      navigate: "پیمایش"
    }
  }
};
// To make it fully compliant, you'd fill out all strings for all languages.
// For this example, we've provided full English, partial Portuguese, Spanish, French, German, and Japanese.
// The app will gracefully fall back to English for missing keys.