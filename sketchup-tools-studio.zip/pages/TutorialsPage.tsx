import React from 'react';
import { useTranslations } from '../lib/i18n';
import PageWrapper from '../components/PageWrapper';
import { motion } from 'framer-motion';

const TutorialSection: React.FC<{ extensionName: string, index: number }> = ({ extensionName, index }) => {
    const { t } = useTranslations();
    // FIX: Corrected type assertion for complex translation object.
    const steps = Object.values(t('tutorials.steps') as unknown as Record<string, { title: string, content: string }>);

    return (
        <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.2 }}
            className="mb-12"
        >
            <h2 className="text-2xl font-semibold border-b pb-2 mb-6">{t('tutorials.byExtension', extensionName)}</h2>
            <div className="space-y-8">
                {steps.map((step, stepIndex) => (
                    <div key={stepIndex} className="flex flex-col md:flex-row gap-6 items-start">
                        <div className="w-full md:w-1/3 aspect-video bg-secondary rounded-lg">
                            <img src={`https://picsum.photos/seed/${extensionName}${stepIndex}/600/400`} alt={step.title} className="w-full h-full object-cover rounded-lg" />
                        </div>
                        <div className="w-full md:w-2/3">
                            <span className="text-sm font-semibold text-primary">STEP {stepIndex + 1}</span>
                            <h3 className="text-xl font-medium mt-1">{step.title}</h3>
                            <p className="mt-2 text-muted-foreground">{step.content}</p>
                        </div>
                    </div>
                ))}
            </div>
        </motion.div>
    );
};


const TutorialsPage: React.FC = () => {
    const { t } = useTranslations();
    // FIX: Corrected type assertion for complex translation object.
    const products = Object.values(t('tools.products') as unknown as Record<string, {name: string}>);

    return (
        <PageWrapper>
            <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold tracking-tight">{t('tutorials.title')}</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground">{t('tutorials.description')}</p>
                </div>

                {products.map((product, index) => (
                    <TutorialSection key={product.name} extensionName={product.name} index={index} />
                ))}
            </div>
        </PageWrapper>
    );
};

export default TutorialsPage;