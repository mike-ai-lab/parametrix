
import React, { useState } from 'react';
import { useTranslations } from '../lib/i18n';
import PageWrapper from '../components/PageWrapper';
import { motion } from 'framer-motion';

const ContactPage: React.FC = () => {
    const { t } = useTranslations();
    const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setStatus('submitting');
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        // Simulate a random outcome
        if (Math.random() > 0.2) {
            setStatus('success');
        } else {
            setStatus('error');
        }
    };

    return (
        <PageWrapper>
            <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold tracking-tight">{t('contact.title')}</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground">{t('contact.description')}</p>
                </div>

                <motion.div 
                    initial={{ opacity: 0, y: 20 }} 
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="max-w-xl mx-auto bg-card border border-border rounded-lg p-8"
                >
                    {status === 'success' ? (
                        <div className="text-center py-10">
                            <h3 className="text-xl font-medium text-green-600">{t('contact.success')}</h3>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-foreground">{t('contact.form.name')}</label>
                                <input type="text" name="name" id="name" required className="mt-1 block w-full rounded-md border-input bg-background shadow-sm focus:border-primary focus:ring-primary sm:text-sm h-10 px-3" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-foreground">{t('contact.form.email')}</label>
                                <input type="email" name="email" id="email" required className="mt-1 block w-full rounded-md border-input bg-background shadow-sm focus:border-primary focus:ring-primary sm:text-sm h-10 px-3" />
                            </div>
                            <div>
                                <label htmlFor="message" className="block text-sm font-medium text-foreground">{t('contact.form.message')}</label>
                                <textarea id="message" name="message" rows={4} required className="mt-1 block w-full rounded-md border-input bg-background shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3"></textarea>
                            </div>
                             {status === 'error' && <p className="text-sm text-destructive">{t('contact.error')}</p>}
                            <div>
                                <button type="submit" disabled={status === 'submitting'} className="w-full inline-flex items-center justify-center rounded-md text-sm font-medium h-10 px-6 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
                                    {status === 'submitting' ? 'Sending...' : t('contact.form.button')}
                                </button>
                            </div>
                        </form>
                    )}
                </motion.div>
            </div>
        </PageWrapper>
    );
};

export default ContactPage;
