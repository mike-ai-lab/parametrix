import React from 'react';
import { useTranslations } from '../lib/i18n';
import PageWrapper from '../components/PageWrapper';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface Plan {
    name: string;
    price: string;
    features: string[];
    button: string;
}

const PricingCard: React.FC<{ plan: Plan, index: number, isFeatured: boolean }> = ({ plan, index, isFeatured }) => {
    const { t } = useTranslations();
    const cardClass = isFeatured 
        ? "border-primary ring-2 ring-primary" 
        : "border-border";

    const buttonClass = isFeatured
        ? "bg-primary text-primary-foreground hover:bg-primary/90"
        : "bg-secondary text-secondary-foreground hover:bg-secondary/80";

    return (
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className={`bg-card rounded-xl p-8 flex flex-col h-full ${cardClass}`}
        >
            <h3 className="text-xl font-semibold">{plan.name}</h3>
            <p className="mt-4">
                <span className="text-4xl font-bold tracking-tight">{plan.price}</span>
                {plan.price !== t('pricing.plans.enterprise.price') && <span className="text-sm text-muted-foreground"> / {t('pricing.perUser')}</span>}
            </p>
            <ul className="mt-6 space-y-4 text-sm flex-grow">
                {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                        <Check className="h-4 w-4 text-green-500 mr-3 mt-1 flex-shrink-0" />
                        <span className="text-muted-foreground">{feature}</span>
                    </li>
                ))}
            </ul>
            <button className={`mt-8 w-full inline-flex items-center justify-center rounded-md text-sm font-medium h-10 px-4 ${buttonClass}`}>
                {plan.button}
            </button>
        </motion.div>
    );
};

const PricingPage: React.FC = () => {
    const { t } = useTranslations();
    // FIX: Corrected type assertion for complex translation object.
    const plans = Object.values(t('pricing.plans') as unknown as Record<string, Plan>);
    
    return (
        <PageWrapper>
            <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold tracking-tight">{t('pricing.title')}</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground">{t('pricing.description')}</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
                    <PricingCard plan={plans[0]} index={0} isFeatured={false} />
                    <PricingCard plan={plans[1]} index={1} isFeatured={true} />
                    <PricingCard plan={plans[2]} index={2} isFeatured={false} />
                </div>
            </div>
        </PageWrapper>
    );
};

export default PricingPage;