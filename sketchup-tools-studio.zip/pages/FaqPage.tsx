import React, { useState } from 'react';
import { useTranslations } from '../lib/i18n';
import PageWrapper from '../components/PageWrapper';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { NavLink } from 'react-router-dom';

interface FAQItem {
    q: string;
    a: string;
}

const AccordionItem: React.FC<{ item: FAQItem, index: number, onToggle: () => void, isOpen: boolean }> = ({ item, index, onToggle, isOpen }) => {
    return (
        <div className="border-b border-border">
            <button
                onClick={onToggle}
                className="flex justify-between items-center w-full py-5 text-left text-lg font-medium text-foreground"
            >
                <span>{item.q}</span>
                <ChevronDown className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        key="content"
                        initial="collapsed"
                        animate="open"
                        exit="collapsed"
                        variants={{
                            open: { opacity: 1, height: 'auto', marginTop: 0, marginBottom: '20px' },
                            collapsed: { opacity: 0, height: 0, marginTop: 0, marginBottom: '0px' }
                        }}
                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                        className="overflow-hidden"
                    >
                        <p className="text-muted-foreground pr-8">{item.a}</p>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

const FaqPage: React.FC = () => {
    const { t } = useTranslations();
    // FIX: Corrected type assertion for complex translation object.
    const questions = Object.values(t('faq.questions') as unknown as Record<string, FAQItem>);
    const [openIndex, setOpenIndex] = useState<number | null>(0);
    
    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <PageWrapper>
            <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold tracking-tight">{t('faq.title')}</h1>
                </div>

                <div className="w-full">
                    {questions.map((item, index) => (
                        <AccordionItem
                            key={index}
                            item={item}
                            index={index}
                            isOpen={openIndex === index}
                            onToggle={() => handleToggle(index)}
                        />
                    ))}
                </div>
                
                <div className="text-center mt-16 p-8 bg-secondary rounded-lg">
                    <h2 className="text-2xl font-semibold">{t('faq.stillNeedHelp')}</h2>
                    <NavLink to="/contact" className="mt-4 inline-flex items-center justify-center rounded-md text-sm font-medium h-10 px-6 bg-primary text-primary-foreground hover:bg-primary/90">
                        {t('faq.contactSupport')}
                    </NavLink>
                </div>
            </div>
        </PageWrapper>
    );
};

export default FaqPage;