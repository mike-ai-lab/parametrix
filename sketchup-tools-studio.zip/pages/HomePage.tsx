
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useTranslations } from '../lib/i18n';
import { motion } from 'framer-motion';
import { Box, Lock, Zap, Settings2 } from 'lucide-react';
import PageWrapper from '../components/PageWrapper';

const HomePage: React.FC = () => {
  const { t } = useTranslations();

  const valueProps = [
    { icon: Box, title: t('home.vp.offline.title'), description: t('home.vp.offline.description') },
    { icon: Lock, title: t('home.vp.privacy.title'), description: t('home.vp.privacy.description') },
    { icon: Zap, title: t('home.vp.automation.title'), description: t('home.vp.automation.description') },
    { icon: Settings2, title: t('home.vp.integration.title'), description: t('home.vp.integration.description') },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <PageWrapper>
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <section className="text-center py-20 sm:py-32">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-6xl font-bold tracking-tighter leading-tight"
          >
            {t('home.headline')}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground"
          >
            {t('home.subheadline')}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-8 flex justify-center gap-4"
          >
            <NavLink to="/tools" className="inline-flex items-center justify-center rounded-md text-sm font-medium h-10 px-6 bg-primary text-primary-foreground hover:bg-primary/90">
              {t('home.exploreTools')}
            </NavLink>
            <NavLink to="/tutorials" className="inline-flex items-center justify-center rounded-md text-sm font-medium h-10 px-6 border border-input bg-background hover:bg-accent hover:text-accent-foreground">
              {t('home.viewTutorials')}
            </NavLink>
          </motion.div>
        </section>

        {/* Value Propositions */}
        <section className="py-16">
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
          >
            {valueProps.map((prop, index) => (
              <motion.div key={index} variants={itemVariants} className="flex flex-col items-center text-center p-4">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-secondary mb-4">
                  <prop.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-medium">{prop.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{prop.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* Product Showcase */}
        <section className="py-16">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight">{t('home.screenshots')}</h2>
          </div>
          <motion.div 
             variants={containerVariants}
             initial="hidden"
             whileInView="visible"
             viewport={{ once: true, amount: 0.2 }}
            className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <motion.div variants={itemVariants} className="bg-secondary rounded-lg aspect-video overflow-hidden">
                <img src="https://picsum.photos/seed/sketchup1/1200/800" alt="Product Screenshot 1" className="w-full h-full object-cover" />
            </motion.div>
            <motion.div variants={itemVariants} className="bg-secondary rounded-lg aspect-video overflow-hidden">
                 <img src="https://picsum.photos/seed/sketchup2/1200/800" alt="Product Screenshot 2" className="w-full h-full object-cover" />
            </motion.div>
             <motion.div variants={itemVariants} className="bg-secondary rounded-lg aspect-video overflow-hidden md:col-span-2">
                 <img src="https://picsum.photos/seed/sketchup3/1200/600" alt="Product Screenshot 3" className="w-full h-full object-cover" />
            </motion.div>
          </motion.div>
        </section>
      </div>
    </PageWrapper>
  );
};

export default HomePage;