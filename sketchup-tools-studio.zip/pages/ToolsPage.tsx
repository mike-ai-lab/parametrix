import React from 'react';
import { useTranslations } from '../lib/i18n';
import { motion } from 'framer-motion';
import PageWrapper from '../components/PageWrapper';

const ProductCard: React.FC<{ name: string, description: string, index: number }> = ({ name, description, index }) => {
    const { t } = useTranslations();
    
    return (
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ y: -5, boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)" }}
            className="bg-card border border-border rounded-xl overflow-hidden flex flex-col"
        >
            <div className="bg-secondary aspect-video">
                <img src={`https://picsum.photos/seed/${name}/600/400`} alt={name} className="w-full h-full object-cover" />
            </div>
            <div className="p-6 flex-grow flex flex-col">
                <h3 className="text-xl font-semibold text-card-foreground">{name}</h3>
                <p className="mt-2 text-muted-foreground text-sm flex-grow">{description}</p>
                <button className="mt-6 w-full inline-flex items-center justify-center rounded-md text-sm font-medium h-9 px-4 bg-secondary text-secondary-foreground hover:bg-secondary/80">
                    {t('tools.viewDetails')}
                </button>
            </div>
        </motion.div>
    );
};

const ToolsPage: React.FC = () => {
    const { t } = useTranslations();
    // FIX: Corrected type assertion for complex translation object.
    const products = Object.values(t('tools.products') as unknown as Record<string, {name: string, description: string}>);

    return (
        <PageWrapper>
            <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold tracking-tight">{t('tools.title')}</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground">{t('tools.description')}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {products.map((product, index) => (
                        <ProductCard key={product.name} name={product.name} description={product.description} index={index} />
                    ))}
                </div>
            </div>
        </PageWrapper>
    );
};

export default ToolsPage;