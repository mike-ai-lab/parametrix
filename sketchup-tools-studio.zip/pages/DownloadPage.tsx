import React from 'react';
import { useTranslations } from '../lib/i18n';
import PageWrapper from '../components/PageWrapper';
import { motion } from 'framer-motion';
import { Download, CheckCircle } from 'lucide-react';

const DownloadPage: React.FC = () => {
    const { t } = useTranslations();
    // FIX: Corrected type assertion for complex translation object.
    const changelogItems = t('download.changelog') as unknown as string[];

    return (
        <PageWrapper>
            <div className="bg-secondary">
                <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-16 text-center">
                    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
                        <h1 className="text-4xl font-bold tracking-tight">{t('download.title')}</h1>
                        <p className="mt-4 text-lg font-medium text-primary">{t('download.version')}</p>
                        <p className="mt-2 text-muted-foreground">{t('download.supported')}</p>
                        <button className="mt-8 inline-flex items-center justify-center rounded-md text-sm font-medium h-12 px-8 bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg">
                            <Download className="mr-2 h-5 w-5" />
                            {t('download.button')}
                        </button>
                    </motion.div>
                </div>
            </div>
            <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-16">
                 <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                    <h2 className="text-2xl font-semibold mb-6">{t('download.changelogTitle')}</h2>
                    <div className="border border-border rounded-lg p-6 bg-card">
                        <ul className="space-y-4">
                            {changelogItems.map((item, index) => (
                                <li key={index} className="flex items-start">
                                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                                    <span className="text-muted-foreground">{item}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </motion.div>
            </div>
        </PageWrapper>
    );
};

export default DownloadPage;